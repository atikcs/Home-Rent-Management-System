C# final project with clear software engineering techniques
